int GetxAty( int y, int x1, int y1, int x2, int y2, bool* pbValid );
int GetyAtx( int x, int x1, int y1, int x2, int y2, bool* pbValid );

