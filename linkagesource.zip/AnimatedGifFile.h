#pragma once
class CAnimatedGifFile
{
public:
	CAnimatedGifFile(void);
	~CAnimatedGifFile(void);
};

