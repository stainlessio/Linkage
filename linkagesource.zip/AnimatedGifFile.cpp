#include "stdafx.h"
#include "AnimatedGifFile.h"


CAnimatedGifFile::CAnimatedGifFile(void)
{
}


CAnimatedGifFile::~CAnimatedGifFile(void)
{
}
